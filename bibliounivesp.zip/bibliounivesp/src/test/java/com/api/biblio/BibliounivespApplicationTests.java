package com.api.biblio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliounivespApplicationTests {

	@Test
	void contextLoads() {
	}

}
